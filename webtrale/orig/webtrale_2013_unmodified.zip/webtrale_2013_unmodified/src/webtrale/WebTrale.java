package webtrale;

import java.io.*;
import java.util.*;

import java.nio.charset.Charset;

import javax.xml.transform.TransformerFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.sax.SAXSource;

import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.dom.DOMResult;
import org.xml.sax.InputSource;

public class WebTrale {
  final static String RESOURCE_PATH = "/webtrale/resources";
  
  Trale _trale;
  TraleMsgParser _traleMsgParser;
  Transformer _trans1, _trans2;
  
  public WebTrale() throws Exception {
    this(7788);
  }
  
  public WebTrale(int port) throws Exception {
    this("localhost", port);
  }
  
  public WebTrale(String host, int port) throws Exception {
    _trale = new Trale(host, port);

    _traleMsgParser = new TraleMsgParser(
      new InputStreamReader(
        WebTrale.class.getResourceAsStream(RESOURCE_PATH + "/_trale-msg.g")
        )
      );
    _trans1 = loadStylesheet(
      TransformerFactory.newInstance(), "/__trale-msg-to-fs-tree.xsl");
  }
  
  private static Transformer loadStylesheet(TransformerFactory tf, String path)
    throws Exception
  {
    try {
      return tf.newTransformer(new SAXSource(new InputSource(
          WebTrale.class.getResourceAsStream(RESOURCE_PATH + path))));
    }
    catch (TransformerException e) {
      throw new TransformerException("stylesheet: " + path, e);
    }
  }
  
  byte[] wordsToXmlByteArray() {
    StringBuilder sb = new StringBuilder();
    
    sb.append("<?xml-stylesheet href='__lexicon.xsl' type='text/xsl'?>\n");
    sb.append("<words>\n");
    
    for (String s : new TreeSet<String>(Arrays.asList(_trale.words()))) {
      sb.append("\t<word uri-encoded-utf8='");
      try {
        sb.append(java.net.URLEncoder.encode(s, "UTF-8"));
      }
      catch (UnsupportedEncodingException e) {
        sb.append("UnsupportedEncodingException");
      }
      sb.append("'>")
        .append(s)
        .append("</word>\n");
    }
    
    sb.append("</words>");
    
    try {
      ByteArrayOutputStream baos = new ByteArrayOutputStream(sb.length());
      PrintWriter out = new PrintWriter(new OutputStreamWriter(baos, "UTF-8"));
      out.print(sb.toString());
      out.close();
      return baos.toByteArray();
    }
    catch (Exception e) {
      throw new RuntimeException(e);
    }
  }
  
  byte[] wordsToHtmlByteArray() {
    StringBuilder sb = new StringBuilder();
    
    //sb.append("<?xml-stylesheet href='__lexicon.xsl' type='text/xsl'?>\n");
    sb.append("<words>\n");
    
    for (String s : new TreeSet<String>(Arrays.asList(_trale.words()))) {
      sb.append("\t<word uri-encoded-utf8='");
      try {
        sb.append(java.net.URLEncoder.encode(s, "UTF-8"));
      }
      catch (UnsupportedEncodingException e) {
        sb.append("UnsupportedEncodingException");
      }
      sb.append("'>")
        .append(s)
        .append("</word>\n");
    }
    
    sb.append("</words>");
    
    try {
      Transformer t = loadStylesheet(TransformerFactory.newInstance(), 
                              "/__lexicon.xsl");
      ByteArrayOutputStream baos = new ByteArrayOutputStream(sb.length());
      t.transform(
        new SAXSource(new InputSource(new StringReader(sb.toString()))),
        new StreamResult(baos)
      );
      return baos.toByteArray();
    }
    catch (Exception e) {
      throw new RuntimeException(e);
    }
  }
  
  byte[] lexToXmlByteArray(String q) throws Exception {
    String[] ss = _trale.lex(q);
    return wrapTraleResult(ss, null);
  }
  
  String[] rec(String q, int maxResults, int maxWords) throws Exception {
    //long start = System.nanoTime();
    String[] ss = _trale.rec(q, maxResults, maxWords);
    //long end = System.nanoTime();
    //System.err.println("-- parsed '" + q + "' in " + ((double)(end - start) / 1000000000) + " secs");
    return ss;
  }
  
  String[] words() {
    return new TreeSet<String>(Arrays.asList(_trale.words())).toArray(new String[0]);
  }
  
  String[] lex(String q) throws Exception {
    return _trale.lex(q);
  }
  
  byte[] parseToXmlByteArray(String q) throws Exception {
    return parseToXmlByteArray(q, Integer.MAX_VALUE);
  }
  
  byte[] parseToXmlByteArray(String q, int maxParses) throws Exception {
    return parseToXmlByteArray(q, maxParses, Integer.MAX_VALUE);
  }
  
  byte[] parseToXmlByteArray(String q, int maxParses, int maxWords) throws Exception {
    String[] ss;
    Trale.TraleException ex;
    try {
      ss = _trale.rec(q, maxParses, maxWords);
      ex = null;
    }
    catch (Trale.TraleException tex) {
      ex = tex;
      ss = new String[0];
    }
    return wrapTraleResult(ss, ex);
  }
  
  byte[] wrapTraleResult(String[] ss, Trale.TraleException tex) throws Exception {
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    
    baos.write(
      "<?xml-stylesheet href='__fs-tree-to-html.xsl' type='text/xsl'?>\n"
      .getBytes());
    baos.write(("<results count='" + ss.length + "'>\n").getBytes());
    
    int pos = 1;
    for (String s : ss) {
      baos.write(("<result id='" + pos + "'>\n").getBytes());
      traleMsgToXml(s, baos);
      baos.write("</result>\n".getBytes());
      ++pos;
    }
    
    if (tex != null) {
      baos.write("<exception>".getBytes());
      baos.write(_traleMsgParser.escapeXml(tex.getMessage()).getBytes());
      baos.write("</exception>".getBytes());
    }
    
    baos.write("</results>".getBytes());
    return baos.toByteArray();
  }
  
  byte[] traleMsgToXml(String s) throws Exception {
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    traleMsgToXml(s, baos);
    return baos.toByteArray();
  }
  
  void traleMsgToXml(String s, OutputStream xmlStream) throws Exception {
    s = _traleMsgParser.parse(s);
    
    synchronized (_trans1) {
      _trans1.transform(
        new SAXSource(new InputSource(new StringReader(s))),
        new StreamResult(xmlStream)
      );
    }
  }
  
  byte[] traleMsgToHtml(String s) throws Exception {
    if (_trans2 == null) {
      _trans2 = loadStylesheet(TransformerFactory.newInstance(), 
                              "/__fs-tree-to-html.xsl");
    }
    s = _traleMsgParser.parse(s);
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    DOMResult domResult = new DOMResult();
    
    synchronized (_trans1) {
      _trans1.transform(
        new SAXSource(new InputSource(new StringReader(s))),
        domResult
      );
    }
    synchronized (_trans2) {
      _trans2.transform(
        new DOMSource(domResult.getNode()),
        new StreamResult(baos)
      );
    }
    
    return baos.toByteArray();
  }
  
  public void close() {
    _trale.close();
  }
  
  public static void main(String[] args) throws Exception {
    String sentence = "peter has been walking";
    Charset cs = Charset.forName("UTF-8");
    if (args.length > 0) {
      sentence = "";
      for (String s : args) sentence += s + " ";
    }
    WebTrale t = new WebTrale();
    byte[] xml = t.parseToXmlByteArray(sentence);
      System.out.println(
      cs.decode(java.nio.ByteBuffer.wrap(xml))
      );
    /*
    for (String s : t.parse(sentence)) { 
      byte[] html = t.traleMsgToHtml(s);
      System.out.println(
      cs.decode(java.nio.ByteBuffer.wrap(html))
      );
    }
    */
    t.close();
  }
}
