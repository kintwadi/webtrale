package webtrale;

import java.io.*;
import java.util.zip.GZIPOutputStream;
import java.util.*;
import java.lang.reflect.*;

public class Utils {
  public static byte[] asciiToBytes(String s) {
    byte[] bs = new byte[s.length()];
    for (int i = 0; i < s.length(); ++i) {
      if (Character.codePointAt(s, i) > 127)
        throw new IllegalArgumentException("Not an ASCII string: " + s);
      bs[i] = (byte) s.charAt(i);
    }
    return bs;
  }
  
  public static void printOptionsForClass(Class clazz, PrintStream out) throws IOException {
    out.println("Options for " + clazz + ":");
    Map<String,Field> m = getOptionFields(clazz);
    for (String opt : m.keySet()) {
      Field f = m.get(opt);
      out.print("  ");
      out.print(opt);
      String t = f.getType().toString();
      if (t.startsWith("class java.lang."))
       t = t.substring("class java.lang.".length());
      else if (t.startsWith("class "))
             t = t.substring("class ".length());
      if (f.getType() == boolean.class)
        out.print("[="); // mark booleans as optional
      else
        out.print('=');
      out.print("<" + t + ">");
      if (f.getType() == boolean.class)
        out.print(']');
      out.print(" (");
      try {
        out.print(f.get(null));
      }
      catch (IllegalAccessException e) {
      }
      out.println(")");
    }
    out.flush();
  }
  
  public static void configureClass(Class clazz, String[] args) {
    Map<String,Field> m = getOptionFields(clazz);
    for (int i = 0; i < args.length; ++i) {
      String arg = args[i];
      String opt = null;
      String val = null;
      int eqpos = arg.indexOf('=');
      if (eqpos == -1) {
        opt = arg;
      }
      else {
        opt = arg.substring(0, eqpos);
        val = arg.substring(eqpos + 1);
      }
      Field f = m.get(opt);
      if (f == null)
        throw new RuntimeException("Unknown option: " + arg);
      Class<?> t = f.getType();
      
      if (eqpos == -1) {
        if (t == boolean.class) {
          try {
            f.setBoolean(null, true);
            continue;
          }
          catch (IllegalAccessException e) {
            throw new RuntimeException(e);
          }
        }
        else {
          throw new RuntimeException("Bad option format: " + arg);
        }
      }
      else if (val.length() == 0 && t != String.class) {
        throw new RuntimeException("Bad option format: " + arg);
      }
      
      try {
        if (boolean.class == t) {
          f.setBoolean(null, Boolean.parseBoolean(val));
        }
        else if (int.class == t) {
          f.setInt(null, Integer.parseInt(val));
        }
        else {
          f.set(null, val);
        }
      }
      catch (Exception e) {
        throw new RuntimeException("A problem occured while processing this option: " + arg, e);
      }
    }
  }
  
  public static boolean configureClass(Class clazz, String[] args, PrintStream err) {
    try {
      configureClass(clazz, args);
      return true;
    }
    catch (Exception e) {
      err.println("<<<<<<<<<<");
      err.println("-- " + e);
      err.println("-- cause: " + e.getCause());
      err.println(">>>>>>>>>>");
      try {
        printOptionsForClass(clazz, err);
      }
      catch (Exception ex)
        { throw new RuntimeException(ex); }
      return false;
    }
  }
  
  static Map<String,Field> getOptionFields(Class clazz) {
    Map<String,Field> m = new TreeMap<String,Field>();
    for (Field f : clazz.getFields()) {
      if ((f.getModifiers() & (Modifier.PUBLIC | Modifier.STATIC)) == 0)
        continue;
      if (!f.getName().startsWith("_"))
        continue;
      Class<?> t = f.getType();
      if (boolean.class != t && int.class != t && String.class != t) {
        continue;
      }
      m.put(f.getName().toLowerCase().replace('_','-'), f);
    }
    return m;
  }
  
  static byte[] gzipBytes(byte[] data) {
    try {
      ByteArrayOutputStream baos = new ByteArrayOutputStream((int) (0.1 * data.length));
      GZIPOutputStream zos = new GZIPOutputStream(baos);
      zos.write(data, 0, data.length);
      zos.finish();
      return baos.toByteArray();
    }
    catch (IOException e) {
      throw new RuntimeException(e);
    }
  }
  
  public static byte[] encodeStrings(String[] ss) {
    return encodeStrings(ss, "\n", "UTF-8");
  }
  
  public static byte[] encodeStrings(String[] ss, String delimiter, String encoding) {
    if (ss == null || ss.length == 0) return new byte[0];
    ByteArrayOutputStream baos = new ByteArrayOutputStream(ss.length * 0x1000);
    try {
      Writer writer = new OutputStreamWriter(baos, encoding);
      for (String s : ss) {
        writer.append(s);
        writer.append(delimiter);
      }
      writer.close();
    }
    catch (Exception e) {
      throw new RuntimeException(e);
    }
    return baos.toByteArray();
  }
  
  public static String millisToTimeString(long ms) {
    long dd = ms / (3600000 * 24);
    long hh = (ms - dd * (3600000 * 24)) / 3600000;
    long mm = (ms - dd * (3600000 * 24) - hh * 3600000) / 60000;
    long ss = (ms - dd * (3600000 * 24) - hh * 3600000 - mm * 60000) / 1000;
    
    StringBuilder sb = new StringBuilder(50);
    if (dd == 1)
      sb.append("1 day, ");
    else if (dd > 1)
      sb.append(dd).append(" days, ");
    
    if (hh == 1)
      sb.append("1 hour, ");
    else if (hh > 1)
      sb.append(hh).append(" hours, ");
  
    if (mm == 1)
      sb.append("1 minute and ");
    else if (mm > 1)
      sb.append(mm).append(" minutes and ");
    
    if (ss == 1)
      sb.append("1 second");
    else
      sb.append(ss).append(" seconds");
      
    return sb.toString();
  }
}
