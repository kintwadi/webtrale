package webtrale;

import java.util.*;
import java.io.*;

public class TraleMsgParser {
  tomato.LRParser _parser;
  
  final static String[] _tokenTypes = {
    "_BEGIN_ANY",
    "_BEGIN_CONJ",
    "_BEGIN_DISJ",
    "_BEGIN_FEATVAL",
    "_BEGIN_FUNCT",
    "_BEGIN_LIST",
    "_BEGIN_REENTR",
    "_BEGIN_REF",
    "_BEGIN_REL",
    "_BEGIN_REST",
    "_BEGIN_SET",
    "_BEGIN_STRUC",
    "_BEGIN_TAIL",
    "_BEGIN_TREE",
    "_INT",
    "_LPAR",
    "_LT",
    "_MINUS",
    "_NEWDATA",
    "_PIPE",
    "_PLUS",
    "_RPAR",
    "_STAR",
    "_STRING",
    "{eof}"
  };
  
  final static String[] _begins = {
    "A", "_BEGIN_ANY",
    "C", "_BEGIN_CONJ",
    "O", "_BEGIN_DISJ",
    "V", "_BEGIN_FEATVAL",
    "F", "_BEGIN_FUNCT",
    "L", "_BEGIN_LIST",
    "R", "_BEGIN_REENTR",
    "#", "_BEGIN_REF",
    "D", "_BEGIN_REL",
    "Y", "_BEGIN_REST",
    "M", "_BEGIN_SET",
    "S", "_BEGIN_STRUC",
    "Z", "_BEGIN_TAIL",
    "T", "_BEGIN_TREE"
  };
  
  final static String[] _singleCharTokens = {
    // "(", "_LPAR", handled in a special way
    ")", "_RPAR",
    "*", "_STAR",
    "<", "_LT",
    "-", "_MINUS",
    "|", "_PIPE",
    "+", "_PLUS"
  };
  
  static String searchStringPairArray(String[] arr, char c) {
    for (int i = 0; i < arr.length; i += 2) {
      if (arr[i].charAt(0) == c)
        return arr[i + 1];
    }
    return null;
  }
  
  Map<String,tomato.Terminal> _tt2term = new TreeMap<String,tomato.Terminal>();
  
  public TraleMsgParser(String grammarFilename) throws Exception {
    this(new FileReader(grammarFilename));
  }
  
  public TraleMsgParser(Reader grammarReader) throws Exception {
    _parser = new tomato.LRParser(grammarReader);
    for (String tt : _tokenTypes) {
      tomato.Terminal term = _parser.grammar().lookupTerminal(tt);
      if (term == null)
        throw new RuntimeException("the LR parser does not know about this terminal: " +
          tt);
      _tt2term.put(tt, term);
    }
  }
  
  tomato.Terminal terminal(String key) {
    tomato.Terminal t = _tt2term.get(key);
    if (t == null)
      throw new RuntimeException("unknown terminal: " + key);
    return t;
  }
  
  static class ParserException extends Exception {
    ParserException() {}
    ParserException(String msg) { super(msg); }
  }
  
  static class TokenizerException extends ParserException {
    TokenizerException() {}
    TokenizerException(String msg) { super(msg); }
  }
  
  static class Token {
    Token() { }
    Token(String s, tomato.Terminal t) { content = s; terminal = t; }
    String content;
    tomato.Terminal terminal;
  }
  
  public String parse(String s) throws ParserException {
    Token[] tokens = null;
    try {
      tokens = tokenize(new StringReader(s));
    }
    catch (TokenizerException e) {
      throw new TokenizerException("for sentence [" + s + "]: " + e);
    }
    tomato.Terminal[] terminals = new tomato.Terminal[tokens.length];
    for (int i = 0; i < tokens.length; ++i) {
      terminals[i] = tokens[i].terminal;
      //if (true) {
      if (false) {
      Token t = tokens[i];
      System.out.print(t.terminal);
      if (t.content != null) System.out.print(" : \"" + t.content + "\"");
      System.out.println();
      }
    }
    //long start = System.currentTimeMillis();
    Iterator it = _parser.parse(terminals);
    //long end = System.currentTimeMillis();
    //System.err.println("-- parsing done in " + (end - start) + " ms.");
    if (!it.hasNext())
      throw new ParserException(
        "trale-msg grammar does not cover the input");
    tomato.Node tree = (tomato.Node) it.next();
    if (it.hasNext())
      throw new ParserException("the input is ambiguous");
    
    return toXmlString(tree, tokens);
  }
  
  String toXmlString(tomato.Node tree, Token[] tokens) {
    StringBuilder sb = new StringBuilder();
    toXmlString(null, tree, tokens, 0, sb);
    return sb.toString();
  }
  
  int toXmlString(tomato.Node parent, tomato.Node node, Token[] tokens, int pos, StringBuilder sb) {
    tomato.Node u = node.firstChild();
    String elementName = node.getObject().toString();
    if (u == null) {
      if (node.getObject() instanceof tomato.Terminal) {
        String s = node.getObject().toString();
        if (s.equals("_INT")) {
          sb.append(tokens[pos].content);
        }
        else if (s.equals("_STRING")) {
          sb.append(escapeXml(tokens[pos].content));
        }
        pos++;
      }
      else {
        sb.append("<").append(elementName).append("/>");
      }
    }
    else {
      sb.append("<").append(elementName).append(">");
      do {
        pos = toXmlString(node, u, tokens, pos, sb);
        u = u.nextSibling();
      }
      while (u != null);
      sb.append("</").append(elementName).append(">");
    }
    
    return pos;
  }
  
  public static String escapeXml(String s) {
    StringBuilder sb = new StringBuilder();
    for (Character c : s.toCharArray()) {
      if (c == '&')
        sb.append("&amp;");
      else if (c == '<')
        sb.append("&lt;");
      else if (c == '>')
        sb.append("&gt;");
      else
        sb.append(c);
    }
    return sb.toString();
  }
  

  Token[] tokenize(StringReader in0) throws TokenizerException {
    PushbackReader in = new PushbackReader(in0);
    ArrayList<Token> tokens = new ArrayList<Token>();
    int pos = 0;
    try {
      while (true) {
        int b = in.read();
        if (b == -1)
          break;
        char c = (char) b;
        pos++;
        
        if (Character.isWhitespace(c))
          continue; // skip whitespace
        
        Token t = new Token();
        
        switch (c) {
          case '"': // string
            {
              StringBuilder s = new StringBuilder();
              while ((b = in.read()) != -1) {
                pos++;
                c = (char) b;
                if (c == '"')
                  break;
                s.append(c);
              }
              if (b == -1)
                throw new TokenizerException("unterminated string");
              t.content  = s.toString();
              t.terminal = terminal("_STRING");
            }
            break;
          
          case '!': //newdata
            {
              String s = "newdata";
              for (int i = 0; i < s.length(); ++i) {
                if (s.charAt(i) != (char) in.read())
                  throw new TokenizerException("expected 'newdata' after '!'");
                pos++;
              }
            }
            t.terminal = terminal("_NEWDATA");
            break;
          
          case '(': // a begin or just an _LPAR?
            {
              b = in.read();
              String tt = "_LPAR";
              if (b != -1) {
                String tt2 = searchStringPairArray(_begins, (char) b);
                if (tt2 != null) {
                  pos++;
                  tt = tt2;
                }
                else
                  in.unread(b);
              }
              t.terminal = terminal(tt);
            }
            break;
          
          default:
            if (Character.isDigit(c)) { // integer
              StringBuilder s = new StringBuilder().append(c);
              while ((b = in.read()) != -1) {
                c = (char) b;
                if (!Character.isDigit(c)) {
                  in.unread(b);
                  break;
                }
                pos++;
                s.append(c);
              }
              t.content  = s.toString();
              t.terminal = terminal("_INT");
            }
            else {
              // single char token?
              String tt = searchStringPairArray(_singleCharTokens, c);
              if (tt == null) {
                throw new TokenizerException("@" + pos
                  + ": invalid token: '" + c + "'");
              }
              t.terminal = terminal(tt);
            }
        }
        tokens.add(t);
      }
    }
    catch (IOException e) {
      // StringReader never throws
    }
    tokens.add(new Token(null, _parser.grammar().eofSymbol()));
    return tokens.toArray(new Token[0]);
  }
  
  public static void main(String[] args) throws Exception {
    TraleMsgParser p = new TraleMsgParser(args[0]);
    BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
    String s;
    while ((s = in.readLine()) != null) {
      System.out.println(
        p.parse(s)
        );
    }
  }
}
